jQuery(function() {
	$('#disclaimer').click(function() {
		$('.disclaimer').toggle();
		return false;
	});
});