# BBCode Icons

Add a Font Awesome icon to your custom BBCode buttons.

## Features

- Add an icon to your custom BBCodes to be displayed on the post editor page.

## Install

1. Add the extension files into the `ext/danieltj/bbcodeicons` directory.
2. Log in to the Admin Control Panel and install the extension.
3. Add or edit a custom BBCode to include an icon for said BBCode.

## Licence

GPL v2
