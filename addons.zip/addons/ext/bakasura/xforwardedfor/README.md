# Installation

Copy the extension to phpBB/ext/bakasura/xforwardedfor

Go to "ACP" > "Customise" > "Extensions" and enable the "X-Forwarded-For" extension.

## License

[GPLv2](license.txt)
