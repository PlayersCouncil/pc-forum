# Changelog

## 1.0.1
* 2024-06

	Font Awesome (brands) version updated from 6.4.2 to 6.5.2 ([FA Changelog](https://fontawesome.com/changelog))

* 2024-12

	Font Awesome (brands) version updated from 6.5.2 to 6.7.1 ([FA Changelog](https://fontawesome.com/changelog))
