## Copyright Extended Changelog

### 1.0.2 - 2021-08-09

- Code update.
- Code cleanup.

### 1.0.1 - 2020-06-22

- Code update version ACP.
- Style adm update.

### 1.0.0 - 2020-05-15

- First release.
