# Modern quote
This extension enables you to highlight parts of posts to quote, similar to the working of quoting from the topic review. 
It also adds a multiquote button to enable you to quote several posts from a page

## Installation

Copy the extension to phpBB/ext/ger/modernquote

Go to "ACP" > "Customise" > "Extensions" and enable the "Modern quote" extension.

## License

[GPLv2](license.txt)
